import java.util.Scanner;
public class VandC{
    public static void main(String [] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a word");
        String word = input.nextLine();
        int vowel = 0;
        int consonant =0;
        for(int i =0; i < word.length(); i++){
            if (word.charAt(i) == ('a') ||  word.charAt(i) == ('e') || word.charAt(i) == ('i') || word.charAt(i) == ('o') || word.charAt(i) == ('u')){
                vowel++;
            }else{
                consonant++;
            }
        }           
        System.out.println("There are " + consonant + " consonants and " + vowel + " vowels");
    }
}