import java.util.Scanner;
public class numwords{
   public static void main (String[] args){
      Scanner input = new Scanner(System.in);
      System.out.println("Please enter a phrase");
      String phrase = input.nextLine();
      System.out.println("The number of words is " + countwords(phrase));
   }
           
   public static int countwords(String phrase){
       String trim = phrase.trim();
       return trim.split("\\W+").length;
     }
   }
    