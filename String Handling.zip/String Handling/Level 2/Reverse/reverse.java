import java.util.Scanner;
public class reverse{
   public static void main (String[] args){
      Scanner input = new Scanner(System.in);
      System.out.println("Please enter a word");
      String phrase = input.nextLine();      
      System.out.println(reverser(phrase));
   }
           
   public static String reverser(String phrase){
       String result ="";
       for(int i=phrase.length()-1; i>-1; i--){
           result = result + phrase.charAt(i);
       }
       return result;
   }
}    