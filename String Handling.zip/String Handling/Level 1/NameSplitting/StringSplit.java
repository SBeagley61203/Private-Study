import java.util.Scanner;
public class StringSplit{
    public static void main (String[] args){
      Scanner input = new Scanner(System.in);      
      System.out.println("Please enter your first and last name seperated by a space");
      String fullname = input.nextLine();
      
      int spacepos = (fullname.indexOf(" "));
      
      System.out.print("Hello ");
      System.out.print(fullname.substring(spacepos+1,fullname.length()));
    }
}
   