import java.util.Scanner;
public class StringInitial{
    public static void main (String[] args){
      Scanner input = new Scanner(System.in);      
      System.out.println("Please enter your first, middle name and last name seperated by a space");
      String fullname = input.nextLine();
      
      int spacepos = (fullname.indexOf(" "));
      int spacepos2 = (fullname.lastIndexOf(" "));
      System.out.print(fullname.charAt(0));     
      System.out.print(fullname.charAt(spacepos+1));
      System.out.println(fullname.charAt(spacepos2+2));
    }
}
   