import java.util.Scanner;
public class verify{
    public static void main (String[] args){
      Scanner input = new Scanner(System.in); 
      boolean verify = false;
       do{
                
        System.out.println("Please enter your password");
        String pword = input.nextLine();
      
        System.out.println("Please enter your password again");
        String pword2 = input.nextLine();
      
        if (pword.equals(pword2)){
            verify = true;
            System.out.println("The passwords match");
        }
        else{
            System.out.println("The password do not match, you will be prompted again to enter your password");
        }
     }while (verify==false);
   }
} 