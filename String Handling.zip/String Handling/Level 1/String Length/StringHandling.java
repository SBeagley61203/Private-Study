import java.util.Scanner;
public class StringHandling{
    public static void main (String[] args){
      Scanner input = new Scanner(System.in);      
      System.out.println("Please enter your name");
      String myname = input.nextLine();
      System.out.println(myname.length());
    }
}
   