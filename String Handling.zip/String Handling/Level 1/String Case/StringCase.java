import java.util.Scanner;
public class StringCase{
    public static void main (String[] args){
      Scanner input = new Scanner(System.in);      
      System.out.println("Please enter your postcode");
      String postcode = input.nextLine();
      System.out.println(postcode.toUpperCase());
    }
}
   