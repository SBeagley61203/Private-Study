import java.util.Scanner;
import java.util.ArrayList;
public class Lottery{
    public static int Ubonus = 0; //So both can be used in both methods
    public static int Lbonus = 0;
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);
        ArrayList<Integer> Unumbers = new ArrayList<>();  //use of array list so the contains function can be used       
        boolean valid = false;
        do{ //makes sure the loop runs once at least
           System.out.println("The numbers must be between 1 and 49"); 
            for(int i = 0; i < 6; i++){ //loops six times for six numbers
              System.out.println("please enter number " + (i+1));
              int validation = input.nextInt(); //checking if any number is above 49
              if(validation>49){
                valid = false;
                System.out.println("one or more number is invalid please re enter all numbers");
              }else{
                Unumbers.add(validation);
                valid = true;
              }
           }      
        }while (valid == false);
        System.out.println("Please enter a bonus ball number");
        Ubonus = input.nextInt(); // bonus ball as seperate inetger instead of in array for the bonus ball matching special win
        
        System.out.print("Your chosen numbers are "); //lists chosen numbers
        for(int i = 0; i < 6; i++){
            System.out.print(Unumbers.get(i) + " ");
        }        
        System.out.print(" your chosen bonus ball is " + Ubonus + "\n"); //lists bonus ball too
        
        int[] Lnumbers = new int [6]; //generating random string of numbers and bonus ball
        int random;
        for (int i = 0; i <6; i++){
            random = (int) (Math.random() * 49);        
            for (int x = 0; x <6; x++){
                if (Lnumbers[x] == random){ //so two numbers are not randomly selected twice
                    random = (int) (Math.random() * 49);
                }
            }
            Lnumbers[i] = random;
        }  
        Lbonus = (int) (Math.random() * 49); 
        
        System.out.print("The Winning numbers are ");
        for(int i = 0; i < 6; i++){
            System.out.print(Lnumbers[i] + " ");
        }
        System.out.print("The winning bonus ball is " + Lbonus);
        
        
        int matching = 0;
        for(int i = 0; i < 6; i++){
           if (Unumbers.contains(Lnumbers[i])){ //checks if the users number array contains value "i" of the lottery array
              matching++;
           }
        }
        
        System.out.println("\n" + "The number of balls you matched you matched is " + matching);
        if (Ubonus == Lbonus){
          System.out.println("Your bonus ball matched");
        }else{
          System.out.println("Your bonus ball did not match");
        }

              
        System.out.println("you won £" + AmountWon(matching)); //outputs winnings
    }
    public static int AmountWon(int matching){ //calculates amount of winnings
        int winnings = 0;
        if((matching == 5) && (Ubonus == Lbonus)){
            winnings = 100000;
        }
        switch (matching){
            default: winnings = 0;
            break;
            
            case 3: winnings = 10;
            break;
            
            case 4: winnings = 100;
            break;
            
            case 5: winnings = 10000;
            break;
            
            case 6: winnings = 1000000;
        }
        return winnings;
    }
}


